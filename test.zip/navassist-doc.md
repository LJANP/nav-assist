# NavAssist

## Purpose / Introduction

NavAssist is a Chrome extension built for Sales Development Representatives (SDRs) and Account Executives (AEs) who use LinkedIn Sales Navigator for prospecting and outreach. It combines two core capabilities under one tool:

1. **Export** — Bulk export prospect data (name, title, tenure, location, outreach status) from Sales Navigator search results and lead lists directly to clipboard or CSV, eliminating manual copy-paste into spreadsheets.

2. **Messaging** — Save reusable message templates with dynamic placeholders that auto-fill with prospect details (name, title, location, tenure) when sending messages or connection requests on Sales Navigator, eliminating manual personalization.

Both features are accessed through a single extension with a tabbed interface. Everything runs locally in the browser — no external servers, no logins, no data leaves the machine.

---

## Problem Statement

Sales teams conducting LinkedIn outreach face two distinct but related bottlenecks:

### Data Collection

DG team members spend considerable time manually copying prospect information (Name, Title, Tenure, Location) from LinkedIn Sales Navigator into spreadsheets. This process involves:

- Opening each profile individually
- Copying fields one at a time
- Switching between LinkedIn and the spreadsheet repeatedly
- Formatting data manually after pasting
- An average of 2 hours per export session

This is time-consuming, error-prone, and creates inconsistent data quality across prospecting lists.

### Message Personalization

SDRs sending outreach messages on LinkedIn face a separate but equally repetitive workflow:

- Copy a message template from a document or notepad
- Paste it into the LinkedIn message field
- Manually type the recipient's name, title, or other details
- Repeat 50-100+ times daily
- An average of 75-90 seconds per message on manual personalization

This leads to typing errors in prospect names, inconsistent messaging across team members, constant context switching, and reduced outreach volume.

Both problems share a root cause: repetitive manual work that takes time away from strategic activities like account research, relationship building, and targeted outreach planning.

---

## Proposed Solution

NavAssist addresses both problems through a single Chrome extension with two feature tabs:

### Export Tab

- An "Export Data" button is injected directly into Sales Navigator search results and lead list pages
- Clicking it scrapes all visible prospect data from the current page (name, title, tenure, location, outreach status)
- Users can capture data across multiple pages — the extension deduplicates by profile URL automatically
- A "Finished" button reveals export options: copy to clipboard (with hyperlinked names in rich text) or download as CSV (with Excel-compatible HYPERLINK formulas)
- A settings panel lets users toggle which fields to include in exports
- A session badge tracks how many prospects have been captured
- Supports three page types: Sales Navigator search results, Sales Navigator lead lists, and regular LinkedIn people search

### Messaging Tab

- Users save reusable subject and message templates directly in the extension popup
- Templates support dynamic placeholders: `{name}`, `{title}`, `{location}`, `{tenure}`
- When a user opens a messaging window or connection invitation modal on Sales Navigator, colored buttons appear above the input fields — "Paste Subject" (green) and "Paste Message" (blue)
- One click pastes the template with all placeholders automatically replaced using the prospect's actual data scraped from the page
- The extension detects the recipient from the messaging window, matches them to their profile card or table row in the search results behind it, and extracts their details in real time
- No pre-capture or setup required — it reads directly from the visible page

### Shared Design

- Single tabbed popup interface (Export | Messaging) with consistent styling
- All data stored locally via Chrome storage APIs — nothing leaves the browser
- No authentication, no accounts, no external dependencies
- Minimal resource usage with zero impact on LinkedIn performance

---

## Success Criteria / Metrics

### Export

| Metric | Target |
|---|---|
| Time spent on data export | 80% reduction vs. manual process |
| Weekly prospects added to outreach lists | 50% increase |
| Data entry errors | 95% reduction |
| Team adoption rate | 90% within first month |
| Internal user satisfaction | 4.5/5 or higher |

### Messaging

| Metric | Target |
|---|---|
| Message personalization time | 90% reduction vs. manual process |
| Naming/personalization errors | Zero |
| Team adoption rate | 90% within first month |
| Daily outreach volume | 50% increase |
| Template formatting issues | 80% reduction |

---

## Impact / Results

Measured results after approximately 1 year in production with the DG team.

### Export

| Metric | Before | After | Impact |
|---|---|---|---|
| Data export time | 2 hours | Under 5 minutes | 95.8% reduction |
| Weekly prospects added | Baseline | 2x | Doubled |
| Team adoption | -- | 100% | Full adoption |

**Time savings:**
- ~115 minutes saved per export session
- Assuming 1 export session per week per person: ~100 hours saved per SDR per year
- ~1,200 hours saved annually across 12-person team

**Qualitative:**
- Eliminated manual copy-paste errors in prospect data
- Reduced context switching between Sales Navigator and spreadsheets
- Enabled team to process larger volumes of prospects in the same time frame
- Freed up time for strategic prospect evaluation rather than data collection

**Post-launch iterations:**
- Added CSV export option based on user feedback to support team members who preferred Excel over Quip
- Added support for Sales Navigator lead list pages
- Added support for regular LinkedIn people search

### Messaging

| Metric | Before | After | Impact |
|---|---|---|---|
| Message personalization time | 62.5 minutes/day | 4.2 minutes/day | 93% reduction |
| Daily outreach volume | Baseline | 50% increase | 50% increase |
| Team adoption | -- | 100% | Full adoption |

**Qualitative:**
- Eliminated naming errors in outreach messages
- Reduced context switching between template sources and LinkedIn
- Enabled SDRs to spend more time on strategic account research
- Improved consistency in messaging across the team

**Post-launch iterations:**
- Expanded functionality to support LinkedIn Sales Navigator leads page
- Added dynamic placeholders for title, location, and tenure — allowing richer personalization beyond just the recipient's name

---

## Next Steps / Call to Action

NavAssist is production-ready, fully client-side, and requires no infrastructure to deploy. Installation takes under a minute with no ongoing maintenance burden.

### Download

[Install NavAssist](#) — Download the extension and get started immediately.

### Need a Walkthrough?

Reach out to @lacst for a full walkthrough of installation, configuration, and best practices for your team.
