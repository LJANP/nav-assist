# Rule #1: Never Guess or Assume

- **Never write code based on guesses or assumptions about external systems, APIs, DOM structures, or anything you don't have verified knowledge of.**
- If you don't know something — ASK. Do not fill in blanks with "educated guesses" or "fallback options."
- This applies especially to: DOM selectors, interaction flows, URL structures, API responses, third-party behavior, and anything that requires inspecting a live system.
- If implementation requires knowledge you don't have, stop and tell the user exactly what you need before writing any code.
- Placeholder/stub code is acceptable ONLY when clearly marked as `// TODO: needs real selectors` and the user is informed.

# Core Development Philosophy

Before implementing any feature or change, ask these three questions:

1. **How do I build this with simplicity in mind?**
   - Favor the smallest solution that works. No over-engineering.
   - If it can be done in fewer files, fewer functions, or fewer dependencies — do that.
   - Vanilla JS over a framework. A loop over a library. A flag over a new system.

2. **How do I avoid adding complexity to the application?**
   - Do not add abstractions, helpers, or utilities for one-off use.
   - Do not design for hypothetical future requirements.
   - Do not add configuration options unless explicitly asked.
   - Three similar lines of code is better than a premature abstraction.

3. **How do I implement this without breaking the application?**
   - Understand existing code before modifying it.
   - Make changes in the smallest possible scope.
   - Prefer adding new code alongside existing code over rewriting it.
   - If a change touches shared state (background service worker, IndexedDB), reason carefully about side effects.
