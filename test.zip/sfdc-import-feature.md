# SFDC Import Feature

Spec for the "Send to SFDC via Kiro" feature. Lets reps push captured LinkedIn prospects into Salesforce by handing off a structured prompt to Kiro CLI, which uses the Salesforce MCP to create the records.

Built in versions. Each version builds on the previous.

---

## Background

The extension already captures LinkedIn prospects into a session (stored in `chrome.storage.local.sessionData`). After capturing, the rep clicks "Finished" and sees export options ("Copy to Clipboard", "Export as CSV"). This feature adds a third option: send the captured data to Salesforce via Kiro.

The extension can't talk to Salesforce or Kiro directly. The handoff is clipboard-based: the extension copies a formatted prompt + JSON. The rep pastes into their Kiro CLI session. Kiro uses the Salesforce MCP to do the actual writes.

Salesforce permissions enforce territory access — if a rep doesn't have access to an account, Salesforce rejects the create. The extension does not pre-validate territory access.

---

## v1 — Contact creation only

### Goal

Add a button to the existing session export options that copies a prompt to the clipboard. Rep pastes into Kiro. Kiro creates Contacts in Salesforce for each captured prospect.

No tasks. No outreach logging. Just contacts.

### UI

A new button — **"Send to SFDC via Kiro"** — placed inline with the existing "Copy to Clipboard" and "Export as CSV" buttons in the session export options wrapper (`#session-export-options`). Order: Copy to Clipboard → Export as CSV → Send to SFDC via Kiro.

To the right of the new button (outside it), a small **info icon (ⓘ)** with a native browser tooltip. Hovering the icon shows:

> "Copies a prompt for Kiro to add these prospects to Salesforce. Requires Kiro CLI with Salesforce MCP."

After the rep clicks the main button:
- The button text briefly changes to **"Copied!"** (~1.5 seconds), then reverts. Same pattern as the existing "Copy to Clipboard" button.
- Below the button row, an inline message appears: **"✓ Copied! Open Kiro, paste, and press Enter."** This message stays for ~4 seconds, then disappears.
- The buttons themselves stay visible the whole time.
- The Reset button is surfaced (same as for the other export buttons).

If the rep clicks the button when no prospects are captured, an alert shows:

> "No prospects captured. Capture some first."

If the clipboard write fails for any reason, an alert shows:

> "Failed to copy to clipboard. Please try again."

### Data flow

1. Rep captures prospects (existing flow)
2. Rep clicks "Finished" → sees export options
3. Rep clicks "Send to SFDC via Kiro"
4. Extension reads `chrome.storage.local.sessionData`
5. Extension generates the SFDC import prompt (instructions + JSON array)
6. Extension copies the prompt to the clipboard
7. SFDC button shows "Copied!" briefly; inline confirmation message "✓ Copied! Open Kiro, paste, and press Enter." appears below the buttons
8. Rep pastes into Kiro
9. Kiro processes each prospect: search account → dedup check → create Contact
10. Kiro outputs a summary (created / duplicates / unmatched / errors)

### JSON shape per prospect

Only fields the extension knows about. Kiro derives anything else (like account ID) at runtime.

```json
{
  "firstName": "Jane",
  "lastName": "Doe",
  "title": "VP of Sales",
  "company": "Expedia Group",
  "linkedInUrl": "https://linkedin.com/in/janedoe"
}
```

### Prompt template

```
Import the following LinkedIn prospects into Salesforce as Contacts.

Rules:
1. Only use field values from the JSON below. Never infer or guess.
2. For each contact:
   a. Run search_accounts with the company name. Only use an accountId
      if the match is exact (case-insensitive) or an obvious variant
      (e.g., "Acme Corp" ↔ "Acme Corporation"). If unsure, skip and
      list under "Unmatched accounts".
   b. Before creating, run search_contacts filtered by the matched
      accountId and the prospect's firstName + lastName. If a match
      is found, skip as duplicate — do not create.
   c. If no duplicate, run create_contact with the provided fields
      plus the accountId.
3. Never create a contact without an accountId. Skip and list as
   unmatched if no account is found.
4. Omit any field not present in the JSON record — do not substitute
   or invent values.
5. Process sequentially. If three consecutive contacts fail for the
   same reason, stop and report.

After completion, output:
- Created: count and list of (name, contact ID)
- Duplicates skipped: count and list of (name, existing contact ID)
- Unmatched accounts: count and list of (name, company)
- Errors: count and list of (name, error)

Contacts:
[ ...JSON array... ]
```

### Behavior on no match

If Kiro can't match a company to a Salesforce Account, the prospect is **skipped**. They appear under "Unmatched accounts" in the summary. They are not created as a Lead. They are not auto-created as a new Account. The rep handles unmatched prospects manually.

### Files modified

- `export-content.js` — add the button + info icon to `insertFinishedButton()` flow, alongside Copy to Clipboard and Export as CSV. Add methods that generate the prompt from `sessionData`, write it to the clipboard, and show the inline confirmation message. The info icon uses a native `title` attribute for the tooltip; no modal markup needed.

No changes to `styles.css`, `popup.html`, `popup.js`, `manifest.json`, or `background.js`.

### Out of scope for v1

- Task creation
- Outreach logging
- Per-rep configuration
- Lead creation when no account matches
- Custom fields beyond what's listed

---

## v2 — Add task logging for sent outreach

### Goal

When the rep imports prospects, ask whether they messaged them. If yes, log a Task per Contact in Salesforce containing the message they sent.

### UI: inline expansion

When the rep clicks "Send to SFDC via Kiro":

1. The export options buttons collapse / are replaced inline with a question:

   > **Did you message these prospects?**
   > [ Yes ]    [ No ]

2. If **No** → revert to v1 behavior (copy contact-only prompt, show post-click confirmation).

3. If **Yes** → the inline area expands further to show:

   > **Which template did you use?**
   > - [ Cold Outreach ]
   > - [ Follow Up ]
   > - [ Thank You ]
   >
   > [ Copy ]   [ Cancel ]

4. Rep selects one template, clicks Copy → extension generates the v2 prompt with task data, copies to clipboard, shows post-click confirmation.

If the rep has **no templates** when they click Yes, show inline:

   > No templates available. Create one in the popup first.

   No template picker. No copy. Rep has to back out, create a template in the popup, come back.

The info icon tooltip in v2 should be updated to mention that the feature can also log outreach as Tasks if the rep messaged the prospects.

### Data flow additions to v1

For each prospect in the captured list, the extension:

1. Resolves the selected template's placeholders per prospect (`{name}`, `{title}`, `{company}`, `{location}`, `{tenure}`) using the same logic as `quickpaste-content.js`.
2. Includes the resolved subject and message in each prospect's JSON record.

### JSON shape per prospect (v2 with task)

```json
{
  "firstName": "Jane",
  "lastName": "Doe",
  "title": "VP of Sales",
  "company": "Expedia Group",
  "linkedInUrl": "https://linkedin.com/in/janedoe",
  "outreach": {
    "subject": "Quick question for Jane",
    "message": "Hey Jane, I saw you're at Expedia Group..."
  }
}
```

If the rep clicks **No** (no outreach), the `outreach` field is omitted entirely. The v1 prompt is used.

### Prompt template (v2 with outreach)

Same v1 prompt with one rule added:

```
6. After successfully creating each contact, also run create_standard_task with:
   - subject: "Sent LinkedIn message via NavAssist"
   - description: the value of outreach.message for that prospect
   - whoId: the new Contact ID
   - activityDate: today
   - status: "Completed"
   - type: "Other"

   Only create the task if the contact was created successfully.
   If the task fails, note it in the errors section but do not roll
   back the contact.
```

The summary report adds:

```
- Tasks created: count
- Tasks failed: count and list of (contact name, error)
```

### Behavior rules for v2

- **One template per batch.** Rep selects one template; it applies to all prospects in the import. No per-prospect template selection.
- **Placeholders are resolved on the extension side**, not by Kiro. The JSON contains the final personalized message body.
- **If outreach is included but a contact fails to create**, no task is created for that prospect.
- **If a contact is skipped as duplicate or unmatched**, no task is created.

### Files modified

- `export-content.js` — extend the inline export options flow to handle the Yes/No question, the template picker, and the conditional prompt generation.

### Out of scope for v2

- Per-prospect template selection
- Detecting whether the message was actually sent (the rep affirms it via Yes)
- Editing the resolved message before import
- Multiple templates in a single batch
- Logging tasks for skipped or duplicate prospects

---

## Future versions (not specced)

Possible directions if real usage justifies them:

- **Per-prospect template selection** — show captured prospects with a template dropdown each
- **Lead creation on no match** — create as a Lead instead of skipping
- **Editable message preview** — let the rep edit the resolved message before import
- **Pre-flight account matching** — if a local Salesforce bridge becomes available, do account matching in the extension before handoff
- **Team profiles** — different prompt templates for Strategic / SMB / Renewals reps if their workflows diverge enough

---

## Anti-hallucination guarantees (across all versions)

The prompt enforces:

- Only use field values from the provided JSON
- Strict account matching (exact or obvious variant only)
- Dedup check before creating
- Never create a contact without an accountId
- Sequential processing with stop-after-3-failures circuit breaker
- Required summary report at the end

These rules sit at the top of the prompt regardless of version.
