# WhatsApp Logging Feature

Spec for adding WhatsApp Web touchpoint logging to NavAssist. Lets reps paste message templates into WhatsApp Web conversations and log each send to Salesforce as an Activity, using the same clipboard → Quicksuite → Salesforce MCP handoff the LinkedIn SFDC import already uses.

This is a **feature add to NavAssist**, not a separate extension. It reuses `background.js` (message router), `chrome.storage.local` (session accumulation), and the existing Quicksuite handoff. The LinkedIn code paths are **never edited** — only new files, new storage keys, and new background actions are added.

Built in versions. Each version builds on the previous.

---

## Background

A LATAM sales team reaches out to customers over WhatsApp Web (`https://web.whatsapp.com/`) and needs those interactions logged and tracked in Salesforce, the same way NavAssist logs LinkedIn outreach. The intent is identical to LinkedIn (MRC / Meaningful Interaction perspective — log the touchpoint); only the UI and available data points differ.

Key facts established with the WhatsApp rep and verified against the live DOM:

- The surface is **standard WhatsApp Web** in a browser (`https://web.whatsapp.com/`) — not the Business app, not a BSP/agent console.
- **All customers being messaged already exist in Salesforce as Contacts.** No Contact creation is needed — only Activity logging against existing Contacts.
- The reliable identifier is the **phone number**. Customer names are almost never saved, so the conversation header shows the phone number in the overwhelming majority of chats.
- Messages sent are **mass templates** — the same message text goes to a large portion of recipients. Personalization placeholders are not needed.

The extension can't talk to Salesforce or Quicksuite directly. The handoff is clipboard-based: the extension copies a formatted prompt + JSON, the rep pastes into their Quicksuite session, and Quicksuite uses the Salesforce MCP to create the Activities.

---

## Verified DOM reference (WhatsApp Web)

Captured live from `https://web.whatsapp.com/`. **Only the `data-testid` / `data-*` / `aria-*` attributes are stable.** The `x1n2onre`-style class names are StyleX atomic hashes that change on every WhatsApp build — never key on them.

| Purpose | Selector / attribute | Notes |
|---|---|---|
| Host | `https://web.whatsapp.com/` | Standard WhatsApp Web |
| Open-chat scope | `div[data-testid="conversation-header"]` | Anchors "the currently open chat" |
| Chat title (number or name) | `span[data-testid="conversation-info-header-chat-title"]` | Shows the **phone number** when no name is saved (the norm), e.g. `+52 1 55 1384 3021`; shows the **name** when one is saved, e.g. `Julia Pessoal` |
| Compose box | `div[data-testid="conversation-compose-box-input"]` | `contenteditable`, `role="textbox"`. Where the template is pasted. |
| Message container | `div[data-testid="msg-container"]` | Wraps each message (not needed in v1 — reference only) |
| Message text | `span[data-testid="selectable-text"]` | Message body (not needed in v1 — reference only) |
| Direction | child `data-testid="tail-out"` (sent) vs `tail-in"` (received) | Not needed in v1 — reference only |
| Time + date + sender | `data-pre-plain-text` = `[HH:MM, DD/MM/YYYY] Sender: ` | Not needed in v1 — reference only |

**v1 uses only two of these:** the chat-title span (to read the phone number) and the compose box (to paste the template).

### Additional observations (v2 reference)

Also seen in the devtools investigation. Not used by v1, recorded so the full findings aren't lost:

- **Per-message sender `aria-label`** — outbound messages carry `aria-label="Você:"` ("You:"); inbound messages carry the sender, which for an unnamed contact is the phone number, e.g. `aria-label="+55 48 9613-7274:"`. A second direction/sender signal alongside `tail-in` / `tail-out`.
- **Stable per-message ID** — each message row exposes `data-id="ACAD7CC9…"` and `data-testid="conv-msg-<id>"`. Useful if a future version needs to dedupe or reference specific messages.
- **`data-testid="msg-meta"`** — the per-message timestamp / delivery-status element (e.g. `16:41` plus the read-receipt SVG, whose `<title>` reads `wds-ic-read`). Separate from the `data-pre-plain-text` string.
- **Compose-box `aria-label` embeds the recipient** — for an unnamed contact it reads `aria-label="Digite uma mensagem para +55 85 9623-3964"` (number); when a name is saved it switches to the name. This mirrors the chat title, so it is **not** a new reliable phone source for the named-contact case — noted only for completeness.

### Phone number availability

- **Unnamed contact (the norm):** the chat-title span contains the phone number. Read it directly.
- **Named contact (rare):** the chat-title span shows the name, and the phone number is **not** available from any stable attribute (the contact-info panel number has only hashed classes). In this case, log by **name** and let the rep reconcile in Salesforce. Do not scrape the classed panel span.

---

## v1 — Paste template + log touchpoint, batch export to SFDC

### Goal

On WhatsApp Web, the rep pastes a saved message template into a conversation via a button (mirroring the LinkedIn quickpaste flow). Each paste is recorded as a touchpoint into a session store. After messaging many prospects, the rep exports the whole batch in one clipboard handoff to Quicksuite, which logs an Activity per touchpoint against the matching Salesforce Contact.

### Workflow (rep's perspective)

1. Rep creates one or more WhatsApp message templates in the extension popup (WhatsApp tab).
2. Rep opens a conversation in WhatsApp Web. A **"Paste Message"** button appears near the compose box.
3. Rep clicks it → the active template's text fills the compose box → a touchpoint is silently recorded (phone number from the chat title + the pasted message text + today's date).
4. Rep sends the message (WhatsApp's own send — the extension does not send).
5. Rep repeats across many conversations (e.g. 50 prospects). A running count is tracked.
6. When done, the rep clicks the **"Send to SFDC via Quicksuite (N)"** button in the top-right of the WhatsApp page → the extension copies **one** prompt + JSON array containing all touchpoints. The button only appears once at least one touchpoint is queued, and its label carries the running count — no need to open the popup, mirroring the LinkedIn Sales Navigator on-page export button.
7. Rep pastes once into Quicksuite. Quicksuite loops: for each touchpoint, digit-match the phone against Salesforce Contact phone fields → create an Activity/Task on the matched Contact.

**Capture is per-conversation; export is one batch.** This mirrors the LinkedIn export flow (accumulate into `sessionData`, then one "Send to SFDC via Quicksuite" handoff).

### Trigger model

- Logging fires on **paste**, not on send — identical to the existing LinkedIn `recordSentMessage` behavior. If a rep pastes but does not send, it still logs. This is a known, accepted limitation (the rep affirms the send by pasting), same as LinkedIn today.
- There is **no automatic DOM-watching** of sent messages. The rep's paste click is the only trigger.

### Templates

- WhatsApp templates are **plain text with no placeholders and no subject line.**
  - No placeholders: messages are mass templates; and `{name}` would resolve to a phone number for unnamed contacts (the norm), producing "Hi +55 48 9613-7274,". Omitting placeholders avoids this entirely.
  - No subject: WhatsApp has no subject field.
- WhatsApp templates are stored under their **own storage key** (`whatsappTemplates`), separate from LinkedIn's `messageTemplates`. Each WhatsApp template has only `{ id, name, message, active }` — no `subject`, no `campaign` (campaign can be added in a later version if needed).
- One template is **active** at a time; the "Paste Message" button pastes the active template. Same active-selection UX as the LinkedIn messaging tab.

### What each paste records (touchpoint)

```json
{
  "phone": "+52 1 55 1384 3021",
  "name": "",
  "message": "Olá! Somos a BagLog...",
  "date": "07/31/26"
}
```

- `phone`: the chat-title text **when it is a phone number** (unnamed contact — the norm). Passed through **exactly as WhatsApp displays it**, no reformatting.
- `name`: populated **only** when the chat title is a saved name (rare); `phone` is then empty. Quicksuite matches by name in this case.
- `message`: the exact template text that was pasted.
- `date`: today, formatted the same way `background.js` `formatSentDate()` already formats LinkedIn sent dates (`MM/DD/YY`).

Exactly one of `phone` / `name` is populated per record, mirroring what the chat title exposed.

### Session accumulation

- Touchpoints accumulate in `chrome.storage.local` under a **new key** (`whatsappTouchpoints`), via a **new background action** (e.g. `recordWhatsAppTouchpoint`). The existing `sessionData` / `capturedUrls` / `sentMessages` keys and the `recordSentMessage` / `sessionAddProspects` actions are **not touched**.
- **Dedup:** unlike LinkedIn (which hard-dedupes prospects by profile URL), do **not** hard-dedupe by phone — a rep may legitimately log the same contact on different days as separate touchpoints. Within a single session, if the rep pastes into the **same chat** more than once, treat it as an accidental repeat: **replace** the prior entry for that phone/name rather than adding a duplicate. Across sessions (after a reset), entries are independent.
- A **count badge** in the popup shows how many touchpoints are queued, mirroring the LinkedIn captured-count display.
- A **Reset** action clears `whatsappTouchpoints` (separate from the LinkedIn reset).

### SFDC handoff (clipboard → Quicksuite → Salesforce MCP)

Reuses the existing pipeline. Because all contacts already exist in Salesforce, the prompt is simpler than the LinkedIn SFDC import — no account search, no contact creation, no create-time dedup. It only finds the existing Contact by phone and logs an Activity.

#### Phone matching (Quicksuite-side, prompt rule)

Salesforce stores phone numbers as free-text with no enforced format. The same org may contain any of:

```
+55 48 9613-7274
+1 (206) 555-1234
206-555-1234
2065551234
+44 20 7946 0958
```

The **extension does not normalize** — it can't know the org's format. Matching is Quicksuite's job, done by digits:

- Strip all non-digit characters from both the captured phone and each candidate Salesforce phone field.
- Compare on the trailing significant digits (to absorb country-code and leading-zero variance).
- If exactly one Contact matches → use it.
- If **more than one** Contact matches, or **none** → do **not** guess. Skip and list under "Unmatched / ambiguous" for the rep to handle.

#### Prompt template (v1)

```
Log the following WhatsApp interactions into Salesforce as completed Activities
on existing Contacts.

Rules:
1. Only use field values from the JSON below. Never infer or guess.
2. For each interaction:
   a. If a phone is present, find the Contact by phone: strip all non-digit
      characters from both the interaction phone and each candidate Contact
      phone field, and compare on the trailing significant digits. Use a
      Contact only if EXACTLY ONE matches.
   b. If a name is present instead of a phone (no phone provided), search
      Contacts by name. Use a Contact only if exactly one clear match exists.
   c. If zero matches, or more than one match, skip and list under
      "Unmatched / ambiguous" — do not guess and do not create a Contact.
3. Never create a Contact. These are all existing Contacts. If none matches,
   the interaction is skipped.
4. For each matched Contact, run create_standard_task (or log an Activity) with:
   - subject: "Sent WhatsApp message via NavAssist"
   - description: the value of "message" for that interaction
   - whoId: the matched Contact ID
   - activityDate: the value of "date" for that interaction
   - status: "Completed"
   - type: "Other"
5. Process sequentially. If three consecutive interactions fail for the same
   reason, stop and report.

After completion, output:
- Logged: count and list of (phone/name, contact ID)
- Unmatched / ambiguous: count and list of (phone/name)
- Errors: count and list of (phone/name, error)

Interactions:
[ ...JSON array of touchpoints... ]
```

### UI

**In WhatsApp Web (`whatsapp-content.js`):**
- A **"Paste Message"** button positioned near the compose box (`conversation-compose-box-input`), following the same positioning/injection approach `quickpaste-content.js` uses for LinkedIn. No "Paste Subject" button.
- On click: read the chat title, fill the compose box with the active template, fire the input event WhatsApp needs to register the text, and send `recordWhatsAppTouchpoint` to the background.
- Brief inline feedback on the button ("Message pasted" / "Pasted (recipient unknown)"), same pattern as LinkedIn.
- A **"Send to SFDC via Quicksuite (N)"** button fixed to the top-right of the page (same placement as the LinkedIn export button), so the rep never has to open the popup. It reads `whatsappTouchpoints`, generates the v1 prompt + JSON, copies to clipboard, and shows the same "✓ Copied! Open Quicksuite, paste, and press Enter." confirmation the LinkedIn SFDC feature uses. A **Reset** button surfaces underneath after a successful copy.
- Button label and visibility are driven by a **single update path** (`refreshSfdcButton`) fed by a `chrome.storage.onChanged` listener on `whatsappTouchpoints`, plus one initial read at inject time. So recording a touchpoint, an on-page Reset, and a Reset done from the popup while WhatsApp is open all keep the button in sync with no page refresh. At a count of 0 the button, confirmation, and Reset all hide.

**In the popup (`popup.html` / `popup.js`):**
- A new **WhatsApp tab** (the popup is already tabbed).
- A template library for WhatsApp templates (name + message only), reusing the LinkedIn template-library UI pattern but reading/writing `whatsappTemplates`.
- A touchpoint count badge + **Reset**. The popup does **not** carry an SFDC handoff button — that lives on the WhatsApp page.

### Files added / modified

**Added:**
- `whatsapp-content.js` — the WhatsApp Web content script (paste button, touchpoint recording, and the on-page SFDC handoff button). New file; injected only on `web.whatsapp.com`.

**Modified (additive only):**
- `manifest.json` — add `https://web.whatsapp.com/*` to `host_permissions`; add a second `content_scripts` entry matching `web.whatsapp.com` → `whatsapp-content.js`. The existing LinkedIn entry is unchanged.
- `background.js` — add a new `recordWhatsAppTouchpoint` action branch writing to `whatsappTouchpoints`. Existing handlers unchanged.
- `popup.html` — add the WhatsApp tab markup.
- `popup.js` — add WhatsApp tab logic: template library over `whatsappTemplates`, touchpoint count/reset. LinkedIn logic unchanged.
- `styles.css` — add the WhatsApp paste button and the fixed-position SFDC button / confirmation / Reset styles. Existing LinkedIn rules unchanged.

**Never touched:**
- `quickpaste-content.js`, `export-content.js` — all LinkedIn DOM logic, including the subject-line function, stays byte-for-byte. WhatsApp gets a separate content script, so there is no path by which the WhatsApp feature can break LinkedIn's subject/quickpaste behavior.

### Why LinkedIn can't break

- Content scripts inject only on URLs matching their own manifest entry. `quickpaste-content.js` runs only on `linkedin.com`; `whatsapp-content.js` runs only on `web.whatsapp.com`. Neither loads on the other's site.
- The only shared surface is `chrome.storage.local` + `background.js`. Cross-contamination is prevented by using **distinct storage keys** (`whatsappTemplates`, `whatsappTouchpoints`) and a **distinct background action** (`recordWhatsAppTouchpoint`). Existing keys/actions are never modified — only new ones added.

### Out of scope for v1

- Placeholders / personalization in WhatsApp templates
- Subject line on WhatsApp
- Capturing inbound messages or full conversation transcripts (v1 logs the pasted outbound template only)
- Logging on send (v1 logs on paste)
- Contact creation (all contacts pre-exist)
- Reading the phone number for named contacts (logged by name, rep reconciles)
- Campaign tags on WhatsApp templates

---

## Future versions (not specced)

Possible directions if real usage justifies them:

- **Campaign tags** on WhatsApp templates, carried into the Activity.
- **Transcript capture** — log the last N messages (both directions) instead of just the pasted template, using `data-pre-plain-text` + `selectable-text` + `tail-in`/`tail-out`.
- **Named-contact phone recovery** — if a stable phone source appears in the DOM, match by phone even when a name is shown.
- **Editable message preview** before logging.

---

## Anti-hallucination guarantees (across all versions)

The Quicksuite prompt enforces:

- Only use field values from the provided JSON
- Digit-based phone matching; use a Contact only on exactly one match
- Never create a Contact (all contacts pre-exist)
- Skip and report on zero or multiple matches — never guess
- Sequential processing with stop-after-3-failures circuit breaker
- Required summary report at the end
